## 5.0.0 - 2016-10-30

- Add support for `options.shell`
- Improve parsing of shebangs by using [`shebang-command`](https://github.com/kevva/shebang-command) module
- Refactor some code to make it more clear
- Update README caveats
