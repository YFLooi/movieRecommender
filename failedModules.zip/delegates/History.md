
1.0.0 / 2015-12-14
==================

  * Merge pull request #12 from kasicka/master
  * Add license text

0.1.0 / 2014-10-17
==================

 * adds `.fluent()` to api

0.0.3 / 2014-01-13
==================

 * fix receiver for .method()

0.0.2 / 2014-01-13
==================

 * Object.defineProperty() sucks
 * Initial commit
