'use strict';
module.exports = require('./boxes.json');
